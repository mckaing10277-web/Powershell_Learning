param (
    [Parameter(Mandatory = $true)]
    [string]$FilePath
)

if (-not (Test-Path $FilePath)) {
    Write-Host "File not found: $FilePath"
    Pause
    exit
}

$BackupFolder = "Backup"
if (-not (Test-Path $BackupFolder)) {
    New-Item -ItemType Directory -Path $BackupFolder | Out-Null
}

$Date = Get-Date -Format "yyyy-MM-dd_HHmmss"
$FileName = Split-Path $FilePath -Leaf
$ZipPath = "$BackupFolder\$FileName-$Date.zip"

Compress-Archive -Path $FilePath -DestinationPath $ZipPath

Write-Host "Backup created:"
Write-Host $ZipPath
Pause
