Add-Type -AssemblyName System.Windows.Forms

# Open file picker
$Dialog = New-Object System.Windows.Forms.OpenFileDialog
$Dialog.Title = "Select a file to back up"
$Dialog.InitialDirectory = [Environment]::GetFolderPath("Desktop")
$Dialog.Filter = "All files (*.*)|*.*"

if ($Dialog.ShowDialog() -ne "OK") {
    Write-Host "No file selected."
    Pause
    exit
}

$FilePath = $Dialog.FileName

# Create Backup folder if needed
$BackupFolder = "Backup"
if (-not (Test-Path $BackupFolder)) {
    New-Item -ItemType Directory -Path $BackupFolder | Out-Null
}

# Create timestamp
$Date = Get-Date -Format "yyyy-MM-dd_HHmmss"
$FileName = Split-Path $FilePath -Leaf
$ZipPath = "$BackupFolder\$FileName-$Date.zip"

# Compress
Compress-Archive -Path $FilePath -DestinationPath $ZipPath

Write-Host "Backup created:"
Write-Host $ZipPath
Pause

